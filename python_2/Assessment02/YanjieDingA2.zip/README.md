# CP1404ProgrammingAssessment2
Project Reflection for CP1404 Assignment: Reading List by Ding Yanjie

1.	How long did the entire project (assignment 2) take you?
I spent a week on this program.

2.	What are you most satisfied with?
Functions and kivy GUI work well.

3.	What are you least satisfied with?
Required button use specific colour.

4.	What worked well in your development process?
Everything is fine.

5.	What about your process could be improved the next time you do a project like this?
Make the interface with the required colour and codes more briefly.

6.	Describe what resources you used and how you used them.
Google search: check the codes which are not in examples, such as background colour of items widgets
Kivydemo, practicals: check the examples and tips to know how to use them well.

7.	Describe the main challenges or obstacles you faced and how you overcame them.
Kivy is the main challenge for me, especially for the marking item. I checked the Kivydemo and practicals to help me overcome most challenges. However, for marking items, I didn’t know how to do it at first, I had tried to use many ways to solve it, but it still didn’t work. Finally, I asked some friends, they helped me to solve some problems and explain to me.
